const express = require('express');
const multer = require('multer');
const fs = require('fs');
const crypto = require('crypto');
const cors = require('cors');

const app = express();
app.use(cors());
const upload = multer();

const algorithm = 'aes-256-cbc';
const key = Buffer.from('0123456789abcdef0123456789abcdef', 'utf8');
const iv = Buffer.from('abcdef9876543210abcdef9876543210', 'hex').slice(0, 16); // Must be 16 bytes

app.post('/decrypt', upload.single('file'), (req, res) => {
  try {
    const encrypted = req.file.buffer;
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    let decrypted = decipher.update(encrypted);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    res.send(decrypted.toString());
  } catch (e) {
    res.status(400).send("Decryption failed");
  }
});

app.listen(5000, () => console.log('Server running on port 5000'));
