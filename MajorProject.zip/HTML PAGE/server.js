const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const { encryptBuffer } = require('./encryptor');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.static('free7.html'));

// Setup Multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Ensure the uploads directory exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Serve all static files from "public"
app.use(express.static(path.join(__dirname, 'free7.html')));

// Open free7.html on home route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname,  'free7.html'));
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'free7.html'));

})

// Endpoint to handle file upload and encryption
app.post('/send-file', upload.single('file'), async (req, res) => {
  const { teamName } = req.body;
  const fileBuffer = req.file.buffer;

  const teamDir = path.join(uploadsDir, teamName);
  if (!fs.existsSync(teamDir)) {
    fs.mkdirSync(teamDir, { recursive: true });
  }

  try {
    const { encryptedData, iv, key } = await encryptBuffer(fileBuffer);
    const filename = `encrypted_${Date.now()}_${req.file.originalname}`;
    const filePath = path.join(teamDir, filename);

    fs.writeFileSync(filePath, encryptedData);

    // Save the IV and key securely; for demonstration, we're saving them in separate files
    fs.writeFileSync(`${filePath}.iv`, iv);
    fs.writeFileSync(`${filePath}.key`, key);

    res.json({ success: true, message: `File sent to ${teamName}` });
  } catch (error) {
    console.error('Encryption error:', error);
    res.status(500).json({ success: false, message: 'Error encrypting file' });
  }
});

app.listen(PORT, () => {
  console.log(`🔐 Secure File Transfer Server running on http://localhost:${PORT}`);
});
