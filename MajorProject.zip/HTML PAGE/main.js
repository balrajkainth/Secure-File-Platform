const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1000,
    height: 700,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'), // 👈 important!
    }
  });

  win.loadFile('index.html');
}

// Open file explorer when button clicked
ipcMain.on('open-file', () => {
  shell.openPath('C:\\Users\\HP\\Downloads\\TeamFiles\\'); // Change path if needed
});

app.whenReady().then(createWindow);
