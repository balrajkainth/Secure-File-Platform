const express=require('express')
const mongoose=require('mongoose')
const path=require('path')
const app=express();

const port= 7000;

app.get('/home',(req,res)=>{
    res.sendFile("__dirname + '/Frontpage.html/employeelogin.html'");

})
console.log(path.join("__dirname,'/Frontpage.html/employeelogin.html'"));
app.use(express.static(path.join(__dirname,'employeelogin.html')));

mongoose.connect('mongodb://localhost:27017',{
    useNewUrlParser: true,
     useUnifiedTopology: true
}).then(()=>{
    console.log("connected to database");
})
const Schema=mongoose.Schema;
const dataSchema=new Schema({
    name:String,
    email:String,
    id:Number,

const Data=mongoose.model('Data',dataSchema);

app.post('employeelogin.html',(req,res)=>{
    const ( name, email, id)=req.body;
    const newData=new Data({}
        name,
        email,
        id,
    })
app.listen(port,()=>{
    console.log(server is running on port ${port});
})