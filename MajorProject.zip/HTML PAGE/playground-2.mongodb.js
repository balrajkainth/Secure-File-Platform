// MongoDB Playground
// Use Ctrl+Space inside a snippet or a string literal to trigger completions.

// The current database to use.
use('file:///C:/Users/HP/HTML%20PAGE/.vscode/employeelogin.html');

// Create a new document in the collection.
db.getCollection('startup_log').insertOne({

});
