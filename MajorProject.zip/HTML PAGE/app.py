from flask import Flask, request
from cryptography.fernet import Fernet

app = Flask(__name__)
key = b'your-32-byte-base64-key-here'  # Save securely
cipher = Fernet(key)

@app.route('/decrypt', methods=['POST'])
def decrypt_file():
    file = request.files['file']
    data = file.read()
    try:
        decrypted = cipher.decrypt(data)
        return decrypted.decode('utf-8')  # Return decrypted text
    except Exception as e:
        return f"Decryption failed: {str(e)}", 400

if __name__ == '__main__':
    app.run(port=5000)
