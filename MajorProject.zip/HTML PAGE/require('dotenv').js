require('dotenv').config();
const express = require('express');
const cors = require('cors');
const twilio = require('twilio');

const app = express();
app.use(cors()); 
app.use(express.json());

const client = new twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH_TOKEN);

// Route to send alert message to the manager
app.post('/alert-manager', async (req, res) => {
    try {
        const message = await client.messages.create({
            body: "🚨 Alert: 2 failed login attempts detected!",
            from: 'whatsapp:+14155238886', // Twilio Sandbox
            to: 'whatsapp:+919877493318'   // Manager's number
        });

        console.log("✅ Alert Sent:", message.sid);
        res.json({ success: true, message_sid: message.sid });

    } catch (error) {
        console.error("❌ Error Sending Alert:", error.message);
        res.status(500).json({ error: error.message });
    }
});

// Start Server on Port 5000
app.listen(5000, () => console.log('🚀 Server running on port 5000'));
