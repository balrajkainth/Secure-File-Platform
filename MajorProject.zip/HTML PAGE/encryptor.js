const crypto = require('crypto');

async function encryptBuffer(buffer) {
  const algorithm = 'aes-256-gcm';
  const key = crypto.randomBytes(32); // Securely store this key
  const iv = crypto.randomBytes(12);

  const cipher = crypto.createCipheriv(algorithm, key, iv);
  const encryptedData = Buffer.concat([cipher.update(buffer), cipher.final()]);
  const authTag = cipher.getAuthTag();

  // Combine the authTag with the encrypted data
  const combinedBuffer = Buffer.concat([encryptedData, authTag]);

  return { encryptedData: combinedBuffer, iv, key };
}

module.exports = { encryptBuffer };
