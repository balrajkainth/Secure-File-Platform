<?php
$targetDirectory = "C:/Users/HP/MANAGER FILES/SEND FILES/";

if (!file_exists($targetDirectory)) {
    mkdir($targetDirectory, 0777, true); // Create the directory if it doesn't exist
}

if (isset($_FILES['file'])) {
    $fileName = basename($_FILES['file']['name']);
    $targetFile = $targetDirectory . $fileName;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
        echo "✅ File uploaded successfully to $targetFile";
    } else {
        echo "❌ Failed to move the uploaded file.";
    }
} else {
    echo "❌ No file uploaded.";
}
?>
