document.addEventListener("DOMContentLoaded", function() {
    const fileInput = document.getElementById('fileInput');
    const uploadButton = document.getElementById('uploadButton');
    const shareablelink = document.getElementById('shareablelink');
  
    async function uploadWithRetry(file, retries = 3, delay = 1000) {
      for (let i = 0; i < retries; i++) {
        try {
          const response = await fetch(`https://transfer.sh/${encodeURIComponent(file.name)}`, {
            method: 'PUT',
            body: file
          });

          // If response is not ok, throw an error
          if (!response.ok) {
            throw new Error(`Upload failed with status: ${response.status}`);
          }

          // Get the download link from the response
          const downloadLink = await response.text();
          return downloadLink; // Return the download link
        } catch (err) {
          console.error(`Attempt ${i + 1} failed:`, err);
          if (i < retries - 1) {
            // Wait before retrying
            await new Promise(resolve => setTimeout(resolve, delay));
          } else {
            // If all retries fail, throw the error to be handled by the caller
            throw err;
          }
        }
      }
    }

    uploadButton.addEventListener('click', async () => {
      const file = fileInput.files[0];
      if (!file) {
        shareablelink.innerHTML = "⚠️ Please select a file.";
        return;
      }

      // Disable the button to prevent multiple uploads
      uploadButton.disabled = true;
      uploadButton.textContent = "Sharing...";

      try {
        // Attempt to upload with retry logic
        const downloadLink = await uploadWithRetry(file);

        // Display the download link if successful
        shareablelink.innerHTML = `<p>✅ <strong>Download File:</strong> <a href="${downloadLink}" target="_blank">${downloadLink}</a></p>`;
      } catch (err) {
        console.error("Upload error:", err);
        shareablelink.innerHTML = `❌ Error uploading file: ${err.message}`;
      } finally {
        // Re-enable the button after the process
        uploadButton.disabled = false;
        uploadButton.textContent = "Share";
      }
    });
});
