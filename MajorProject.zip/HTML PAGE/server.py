require('dotenv').config();

require('dotenv').config(); // Load .env file

const express = require('express');
const cors = require('cors');
const twilio = require('twilio');

const app = express();
app.use(cors());
app.use(express.json());
const client = new (require('twilio'))(process.env.TWILIO_SID, process.env.TWILIO_AUTH_TOKEN);


app.post('/alert-manager', (req, res) => {
    const { message } = req.body;

    client.messages
        .create({
            body: message,
            from: 'whatsapp:+14155238886',
            to: 'whatsapp:+919877493318'
        })
        .then(() => res.json({ success: true }))
        .catch(error => res.status(500).json({ error: error.message }));
});

app.listen(5000, () => console.log('✅ Server running on port 5000'));
app.get('/', (req, res) => {
    res.json({ message: 'Hello from the server!' });
});
