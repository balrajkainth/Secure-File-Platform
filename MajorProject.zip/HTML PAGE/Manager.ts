<!-- Combined Secure Web Collaboration Platform with Employee Login Page -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Secure Web Collaboration Platform</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
    body { background: linear-gradient(135deg, #1abc9c, #3498db); color: whitesmoke; text-align: center; min-height: 100vh; }
    .header { padding: 20px; font-size: 28px; font-weight: bold; background: rgba(0, 0, 0, 0.3); border-radius: 10px; }
    .dashboard { display: flex; justify-content: center; flex-wrap: wrap; gap: 20px; margin-top: 20px; }
    .card { background: rgba(255, 255, 255, 0.2); padding: 20px; border-radius: 15px; width: 260px; cursor: pointer; transition: 0.3s; }
    .card:hover { transform: translateY(-5px); }
    .button { padding: 10px 20px; background: #ffcc00; color: black; border-radius: 20px; font-weight: bold; text-decoration: none; }
    .login-container { background: rgba(0, 0, 0, 0.5); padding: 40px; border-radius: 15px; width: 350px; margin: 40px auto; }
    .login-container input { width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 8px; border: 1px solid #ccc; }
    .login-btn { padding: 12px; background-color: #ffcc00; border-radius: 20px; font-weight: bold; cursor: pointer; }
  </style>
</head>
<body>
  <div class="header">SECURE WEB COLLABORATION PLATFORM</div>
  <div class="dashboard">
    <div class="card" onclick="location.href='manager_dashboard.html';">
      <h3>Manager</h3><p>Manage employees and security.</p><a href="#" class="button">Get Started</a>
    </div>
    <div class="card" onclick="location.href='employee_login.html';">
      <h3>Employee</h3><p>Collaborate and share files.</p><a href="#" class="button">Get Started</a>
    </div>
    <div class="card" onclick="location.href='team_dashboard.html';">
      <h3>Team</h3><p>Coordinate tasks.</p><a href="#" class="button">Get Started</a>
    </div>
  </div>

  <!-- Employee Login Section -->
  <div class="login-container">
    <h2>Employee Login</h2>
    <form>
      <input type="email" placeholder="Enter your email" required>
      <input type="password" placeholder="Enter your password" required>
      <button type="submit" class="login-btn">Login</button>
    </form>
  </div>

  <footer>&copy; 2025 Secure Web Collaboration Platform. All rights reserved.</footer>
</body>
</html>
